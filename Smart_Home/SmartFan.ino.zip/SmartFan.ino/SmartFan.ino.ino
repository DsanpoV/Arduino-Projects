/*
 * NANO 33 BLE - VERSÃO FINAL + RAW VIEW
 * Igual à versão estável, mas mostra o valor bruto da decisão.
 */

#include <TensorFlowLite.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "fan_model.h"

#define IN1 12   
#define IN2 11   
#define LED_RED 22
#define LED_GREEN 23
#define LED_BLUE 24

namespace {
  const tflite::Model* model = nullptr;
  tflite::MicroInterpreter* interpreter = nullptr;
  TfLiteTensor* input = nullptr;
  TfLiteTensor* output = nullptr;
  
  // MANTIDO: 4KB (Não mexemos no que funciona!)
  constexpr int kTensorArenaSize = 4 * 1024; 
  alignas(16) uint8_t tensor_arena[kTensorArenaSize];
}

void setup() {
  Serial.begin(9600);
  
  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(LED_RED, OUTPUT); pinMode(LED_GREEN, OUTPUT); pinMode(LED_BLUE, OUTPUT);
  digitalWrite(IN2, LOW); analogWrite(IN1, 0);
  digitalWrite(LED_RED, HIGH); digitalWrite(LED_GREEN, HIGH); digitalWrite(LED_BLUE, HIGH);

  setRGB(0, 0, 1); // Azul

  model = tflite::GetModel(g_fan_model);
  static tflite::AllOpsResolver resolver;
  static tflite::MicroInterpreter static_interpreter(model, resolver, tensor_arena, kTensorArenaSize);
  interpreter = &static_interpreter;

  if (interpreter->AllocateTensors() != kTfLiteOk) {
    Serial.println("Erro Memoria");
    while(1); 
  }

  input = interpreter->input(0);
  output = interpreter->output(0);

  Serial.println("=== SF PRONTO (COM RAW VIEW) ===");
  setRGB(0, 1, 0); delay(1000); setRGB(0,0,0);
}

void loop() {
  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.startsWith("DATA:")) parseAndRunInference(line.substring(5));
  }
}

void parseAndRunInference(String data) {
  int firstComma = data.indexOf(',');
  int secondComma = data.lastIndexOf(',');
  if (firstComma == -1 || secondComma == -1) return;
  
  float temp = data.substring(0, firstComma).toFloat();
  float hum = data.substring(firstComma + 1, secondComma).toFloat();
  float userCode = data.substring(secondComma + 1).toFloat();
  
  input->data.int8[0] = (int8_t)temp;
  input->data.int8[1] = (int8_t)hum;
  input->data.int8[2] = (int8_t)userCode;

  if (interpreter->Invoke() != kTfLiteOk) return;

  // === AQUI ESTÁ A MUDANÇA VISUAL ===
  int8_t resultado_raw = output->data.int8[0];
  bool ligar = resultado_raw > 0; 
  
  // Imprime o valor da certeza (-128 a 127)
  Serial.print("Raw: "); Serial.print(resultado_raw);
  Serial.print(" -> Decisao: "); Serial.println(ligar ? "1" : "0");

  if (ligar) {
    analogWrite(IN1, 180);
    setRGB(0, 1, 0);
  } else {
    analogWrite(IN1, 0);
    setRGB(1, 0, 0);
  }
}

void setRGB(int r, int g, int b) {
  digitalWrite(LED_RED, r ? LOW : HIGH);
  digitalWrite(LED_GREEN, g ? LOW : HIGH);
  digitalWrite(LED_BLUE, b ? LOW : HIGH);
}