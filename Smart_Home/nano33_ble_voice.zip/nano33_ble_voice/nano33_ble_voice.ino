/*
 * SISTEMA DE RECONHECIMENTO DE VOZ - ARDUINO NANO 33 BLE
 * CÓDIGO ORIGINAL - APENAS ALTERADA A COMUNICAÇÃO PARA USB
 */

#include <TensorFlowLite.h>
#include "audio_provider.h"
#include "feature_provider.h"
#include "main_functions.h"
#include "micro_features_micro_model_settings.h"
#include "micro_features_model.h"
#include "recognize_commands.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"

// ================================================================
// TA6586 - Controlo da ventoinha
// ================================================================
#define IN1 12   // PWM (velocidade)
#define IN2 11   // Direção fixa

// ================================================================
// LED RGB INTEGRADO DO NANO 33 BLE
// ================================================================
#define LED_RED 22
#define LED_GREEN 23
#define LED_BLUE 24

// ================================================================
// VARIÁVEIS DE ESTADO
// ================================================================
bool fanState = false;
unsigned long lastStatusReport = 0;
const unsigned long STATUS_INTERVAL = 30000; // 30 segundos
unsigned long lastCommand = 0;
const unsigned long COMMAND_COOLDOWN = 3000; // 3 segundos entre comandos

// ================================================================
// Globals TensorFlow Lite
// ================================================================
namespace {
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* model_input = nullptr;
FeatureProvider* feature_provider = nullptr;
RecognizeCommands* recognizer = nullptr;
int32_t previous_time = 0;

constexpr int kTensorArenaSize = 10 * 1024;
alignas(16) uint8_t tensor_arena[kTensorArenaSize];
int8_t feature_buffer[kFeatureElementCount];
int8_t* model_input_buffer = nullptr;
}  // namespace

// ================================================================
// SETUP
// ================================================================
void setup() {
  Serial.begin(9600);  // ALTERADO: USB (PC) em vez de Serial1
  // Serial1.begin(9600); // DESLIGADO
  
  // AVISO: O Nano 33 BLE precisa que o Monitor Serial abra para arrancar o USB
  // Se quiseres que funcione na parede sem PC, tens de remover a linha abaixo:
  // while (!Serial); 

  Serial.println("=== NANO 33 BLE - USB MODE ===");
  
  // Inicializa LEDs RGB
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
  setRGBLED(0, 0, 255); // Azul = inicializando
  
  // Inicializa TensorFlow Lite
  tflite::InitializeTarget();
  
  model = tflite::GetModel(g_model);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    Serial.println("Model version incompatible!");
    setRGBLED(255, 0, 0); // Vermelho = erro
    return;
  }
  
  static tflite::MicroMutableOpResolver<4> micro_op_resolver;
  micro_op_resolver.AddDepthwiseConv2D();
  micro_op_resolver.AddFullyConnected();
  micro_op_resolver.AddSoftmax();
  micro_op_resolver.AddReshape();
  
  static tflite::MicroInterpreter static_interpreter(
      model, micro_op_resolver, tensor_arena, kTensorArenaSize);
  interpreter = &static_interpreter;
  
  if (interpreter->AllocateTensors() != kTfLiteOk) {
    Serial.println("AllocateTensors() failed");
    setRGBLED(255, 0, 0); // Vermelho = erro
    return;
  }
  
  model_input = interpreter->input(0);
  model_input_buffer = model_input->data.int8;
  
  static FeatureProvider static_feature_provider(kFeatureElementCount, feature_buffer);
  feature_provider = &static_feature_provider;
  
  static RecognizeCommands static_recognizer;
  recognizer = &static_recognizer;
  
  previous_time = 0;
  
  if (InitAudioRecording() != kTfLiteOk) {
    Serial.println("Unable to initialize audio");
    setRGBLED(255, 0, 0); // Vermelho = erro
    return;
  }
  
  Serial.println("✓ Voz inicializada");
  
  // Inicializa pinos do TA6586
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  digitalWrite(IN2, LOW); // direção fixa
  analogWrite(IN1, 0);    // ventoinha desligada inicialmente
  
  Serial.println("✓ Ventoinha pronta");
  
  setRGBLED(0, 255, 0); // Verde = pronto
  delay(500);
  setRGBLED(0, 0, 0);   // Desliga LED
}

// ================================================================
// LOOP
// ================================================================
void loop() {
  processAudioRecognition();
  
  if (millis() - lastStatusReport > STATUS_INTERVAL) {
    sendStatus();
    lastStatusReport = millis();
  }
  
  processIncomingCommands();
  
  delay(50);
}

// ================================================================
// RECONHECIMENTO DE VOZ
// ================================================================
void processAudioRecognition() {
  const int32_t current_time = LatestAudioTimestamp();
  int how_many_new_slices = 0;
  
  if (feature_provider->PopulateFeatureData(
      previous_time, current_time, &how_many_new_slices) != kTfLiteOk) {
    return;
  }
  
  previous_time += how_many_new_slices * kFeatureSliceStrideMs;
  if (how_many_new_slices == 0) return;
  
  for (int i = 0; i < kFeatureElementCount; i++) {
    model_input_buffer[i] = feature_buffer[i];
  }
  
  if (interpreter->Invoke() != kTfLiteOk) {
    return;
  }
  
  TfLiteTensor* output = interpreter->output(0);
  const char* found_command = nullptr;
  uint8_t score = 0;
  bool is_new_command = false;
  
  recognizer->ProcessLatestResults(
      output, current_time, &found_command, &score, &is_new_command);
  
  if (found_command != nullptr && is_new_command) {
    if (millis() - lastCommand < COMMAND_COOLDOWN) return;
    
    // DEBUG NO PC
    Serial.print("Comando: ");
    Serial.println(found_command);
    
    if (strcmp(found_command, "yes") == 0) {
      if (!fanState) turnFanOn();
    } else if (strcmp(found_command, "no") == 0) {
      if (fanState) turnFanOff();
    }
    lastCommand = millis();
  }
}

// ================================================================
// CONTROLE DA VENTOINHA
// ================================================================
void turnFanOn() {
  fanState = true;
  analogWrite(IN1, 180); 
  
  // ALTERADO: Envia via USB para o PC
  Serial.println("EVENT_FAN_ON"); 
  flashRGBLED(0, 255, 0, 2); 
}

void turnFanOff() {
  fanState = false;
  analogWrite(IN1, 0);
  
  // ALTERADO: Envia via USB para o PC
  Serial.println("EVENT_FAN_OFF");
  flashRGBLED(255, 0, 0, 2); 
}

// ================================================================
// COMUNICAÇÃO COM O PC
// ================================================================
void processIncomingCommands() {
  // ALTERADO: Lê do USB (Serial)
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    
    if (cmd == "FORCE_ON") {
      if (!fanState) turnFanOn();
    }
    else if (cmd == "FORCE_OFF") {
      if (fanState) turnFanOff();
    }
  }
}

void sendStatus() {
  // Serial.println("STATUS_OK");
}

void setRGBLED(int r, int g, int b) {
  digitalWrite(LED_RED, r > 0 ? LOW : HIGH);
  digitalWrite(LED_GREEN, g > 0 ? LOW : HIGH);
  digitalWrite(LED_BLUE, b > 0 ? LOW : HIGH);
}

void flashRGBLED(int r, int g, int b, int times) {
  for (int i = 0; i < times; i++) {
    setRGBLED(r, g, b);
    delay(150);
    setRGBLED(0, 0, 0);
    delay(150);
  }
}